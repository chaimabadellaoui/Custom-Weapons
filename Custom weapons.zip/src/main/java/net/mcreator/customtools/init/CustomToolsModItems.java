
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.customtools.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.customtools.item.ObsidianIngotItem;
import net.mcreator.customtools.item.ObsidianArmorItem;
import net.mcreator.customtools.item.ObisidianSwordItem;
import net.mcreator.customtools.item.ObisidianShovelItem;
import net.mcreator.customtools.item.ObisidianPickaxeItem;
import net.mcreator.customtools.item.ObisidianHoeItem;
import net.mcreator.customtools.item.ObisidianAxeItem;
import net.mcreator.customtools.CustomToolsMod;

public class CustomToolsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CustomToolsMod.MODID);
	public static final RegistryObject<Item> OBISIDIAN_AXE = REGISTRY.register("obisidian_axe", () -> new ObisidianAxeItem());
	public static final RegistryObject<Item> OBISIDIAN_PICKAXE = REGISTRY.register("obisidian_pickaxe", () -> new ObisidianPickaxeItem());
	public static final RegistryObject<Item> OBISIDIAN_SWORD = REGISTRY.register("obisidian_sword", () -> new ObisidianSwordItem());
	public static final RegistryObject<Item> OBISIDIAN_SHOVEL = REGISTRY.register("obisidian_shovel", () -> new ObisidianShovelItem());
	public static final RegistryObject<Item> OBISIDIAN_HOE = REGISTRY.register("obisidian_hoe", () -> new ObisidianHoeItem());
	public static final RegistryObject<Item> OBSIDIAN_BLOCK = block(CustomToolsModBlocks.OBSIDIAN_BLOCK, null);
	public static final RegistryObject<Item> OBSIDIAN_ARMOR_HELMET = REGISTRY.register("obsidian_armor_helmet", () -> new ObsidianArmorItem.Helmet());
	public static final RegistryObject<Item> OBSIDIAN_ARMOR_CHESTPLATE = REGISTRY.register("obsidian_armor_chestplate", () -> new ObsidianArmorItem.Chestplate());
	public static final RegistryObject<Item> OBSIDIAN_ARMOR_LEGGINGS = REGISTRY.register("obsidian_armor_leggings", () -> new ObsidianArmorItem.Leggings());
	public static final RegistryObject<Item> OBSIDIAN_ARMOR_BOOTS = REGISTRY.register("obsidian_armor_boots", () -> new ObsidianArmorItem.Boots());
	public static final RegistryObject<Item> OBSIDIAN_INGOT = REGISTRY.register("obsidian_ingot", () -> new ObsidianIngotItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
